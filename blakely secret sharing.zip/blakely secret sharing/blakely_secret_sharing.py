import numpy as np
from sympy import symbols, Eq, solve

class BlakelySecretSharing:
    def __init__(self, n, k):
        """
        Initialize the Blakely Secret Sharing scheme.
        :param n: Total number of participants
        :param k: Minimum number of participants required to reconstruct the secret
        """
        self.n = n
        self.k = k

    def generate_shares(self, secret):
        """
        Generate shares (hyperplane equations) from the given secret.
        :param secret: The secret to be shared
        :return: List of shares (each share is a hyperplane equation)
        """
        # Generate a random k-dimensional secret point (including the secret)
        secret_point = np.random.randint(1, 100, size=self.k-1).tolist()
        secret_point.append(secret)  # Last coordinate is the secret

        # Generate random normal vectors for k-1 hyperplanes
        normal_vectors = [np.random.randint(1, 20, size=self.k) for _ in range(self.n)]

        # Compute shares (dot product of normal vectors with secret point)
        shares = []
        for i in range(self.n):
            d = np.dot(normal_vectors[i], secret_point)
            shares.append((normal_vectors[i], d))  # Each share is (normal vector, d)

        return shares

    def reconstruct_secret(self, shares):
        """
        Reconstruct the secret using k shares.
        :param shares: List of k shares (normal vector, d)
        :return: Reconstructed secret
        """
        if len(shares) < self.k:
            raise ValueError("At least k shares are required to reconstruct the secret")

        # Extract the k normal vectors and d values
        A = np.array([share[0] for share in shares])  # Matrix of normal vectors
        b = np.array([share[1] for share in shares])  # Right-hand side values

        # Solve the system of linear equations Ax = b
        secret_point = np.linalg.solve(A, b)

        return round(secret_point[-1])  # Return the last coordinate as the secret

if __name__ == "__main__":
    # Define total participants (n) and threshold (k)
    n, k = 5, 3
    secret = 42  # The secret to share

    # Initialize Blakely's scheme
    blakely = BlakelySecretSharing(n, k)

    # Generate shares
    shares = blakely.generate_shares(secret)
    print("\nGenerated Shares:")
    for i, share in enumerate(shares):
        print(f"Share {i+1}: Normal Vector = {share[0]}, d = {share[1]}")

    # Select k shares to reconstruct the secret
    selected_shares = shares[:k]  # Select the first k shares

    # Reconstruct the secret
    reconstructed_secret = blakely.reconstruct_secret(selected_shares)
    print(f"\nReconstructed Secret: {reconstructed_secret}")
